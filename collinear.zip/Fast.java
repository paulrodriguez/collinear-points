/***
  * Author:       Paul Rodriguez
  * Created:      2/27/2014
  * LastUpdated:  2/28/2014
  * 
  * Compilation:  javac Fast.java
  * Execution:    java Fast input.txt
  */

import java.util.Arrays;
public class Fast
{
   
    public static void main(String[] args)
    {
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.show(0);
        
        In file = new In(args[0]);
        int N = file.readInt();
        Point[] points = new Point[N];
        
       
        for (int i = 0; i < N; i++)
        {
            points[i] = new Point(file.readInt(), file.readInt());
            points[i].draw();
            StdDraw.show(0);
        }
        
        Point prevPoint = null;
        Arrays.sort(points);
     
        StdOut.println("");
        
        Point[] sortedPoints = new Point[N];
        
        for (int i = 0; i < N; i++)
        {
           
            System.arraycopy(points, 0, sortedPoints, 0, N);
            
            Arrays.sort(sortedPoints, i, N, sortedPoints[i].SLOPE_ORDER);
           
            //System.arraycopy(points, 0, sortedPoints, 0, sortedPoints.length);
            //StdOut.println("current point: "+sortedPoints[i].toString());
           // StdOut.println("ordered arrays:"+ Arrays.toString(sortedPoints));
            //StdOut.println("test");
          /*  Point[] subarray = new Point[N-i];
            for (int j = i; j < N; j++)
            {
                subarray[j-i] = points[j];
                StdOut.println("subarray loop: "+subarray[j-i]);
            }
            */
            
        //    Arrays.sort(subarray, points[i].SLOPE_ORDER);
            
            double prevSlope = 0.0;
            //  pointers group of adjacent points with equal slopes
            int start = i+1;
            int end = i;
            for (int j = i+1; j < N; j++)
            {
                //StdOut.println("high counter: "+highPos+", low counter: "+lowPos);
                double currSlope = sortedPoints[i].slopeTo(sortedPoints[j]);
                //StdOut.println("prev slope: "+prevSlope+", curr slope: "+currSlope);
                if (prevSlope == currSlope)
                {
                    end++;
                }
                else
                {
                    if (end-start >= 2 && prevPoint != sortedPoints[end])
                    {
                        
                        prevPoint = sortedPoints[end];
                       
                        StdOut.print(sortedPoints[i]);
                        for (int k = start; k <= end; k++)
                        {
                            StdOut.print(" -> " + sortedPoints[k]);
                        }
                        StdOut.println("");
                        sortedPoints[i].drawTo(sortedPoints[end]);
                        
                    }
                    start  = j;
                    end    = j;
                    prevSlope = currSlope;
                }
            }
            
            if (end-start >= 2 && prevPoint != sortedPoints[end])
            {
                        
                prevPoint = sortedPoints[end];
                StdOut.print(points[i]);
                
                for (int k = start; k <= end; k++)
                {
                    StdOut.print(" -> " + sortedPoints[k]);
                }
                StdOut.println("");   
                sortedPoints[i].drawTo(sortedPoints[end]);
            }
            
        }
        
        StdDraw.show(0);
    }
}